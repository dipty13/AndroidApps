package com.dnerd.dipty.mychatapplication;


import android.support.v4.app.Fragment;

public class FriendsFragment extends Fragment {




}
