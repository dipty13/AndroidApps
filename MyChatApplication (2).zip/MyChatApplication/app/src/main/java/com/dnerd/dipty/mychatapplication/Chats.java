package com.dnerd.dipty.mychatapplication;

public class Chats {
    private String user_status;

    public Chats() {
    }

    public String getUser_status() {
        return user_status;
    }

    public void setUser_status(String user_status) {
        this.user_status = user_status;
    }

    public Chats(String user_status) {

        this.user_status = user_status;
    }
}
